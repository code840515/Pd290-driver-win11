# Pd290 Windows 11 相容驅動與 WinUSB 轉送服務

這是 Pd290 58 mm 熱感式印表機在 Windows 11 x64 上的實驗性相容方案，適用於 USB 裝置識別碼 `VID_067B&PID_2305`（PL2305／IEEE-1284 bridge）。

## 已驗證狀態

- Windows 11 x64 可由一般使用者列印 Windows 測試頁
- 印表機驅動版本：2.0.0.2
- PL2305 使用 Microsoft 內建 `winusb.sys`
- `PU290WinUsbRelay` 服務將完成的列印工作轉送至 WinUSB Bulk OUT
- 不需要開啟 Windows 測試模式，也不應停用 Secure Boot、核心隔離或驅動程式簽章強制

## 安裝

1. 從 Releases 下載最新的 `Pd290-Win11-working.zip`。
2. 完整解壓縮。
3. 開啟印表機電源並連接 USB-B 對 USB-A 線。
4. 執行 `Install-Pd290.cmd`，接受系統管理員權限提示。
5. 在 Windows 設定中選擇 `Pd290-Win11` 並列印測試頁。

詳細步驟請參閱 [NEW-PC-INSTALL.zh-TW.md](NEW-PC-INSTALL.zh-TW.md)。

## 安全性聲明

本專案使用自簽測試憑證簽署驅動套件目錄。安裝腳本會在明確執行後，將公開憑證加入本機電腦的「受信任的根憑證授權單位」與「受信任的發行者」。

- 儲存庫與發佈 ZIP **不包含私密金鑰**。
- 測試憑證有效期限至 2027-07-16。
- 這不是 Microsoft WHQL 或硬體廠商正式簽章套件。
- 為保持已簽章套件與既有安裝相容，少數內部服務與資料路徑仍沿用舊的 `PU290` 識別；公開檔名已統一為 `Pd290`。
- 正式大量部署前，建議改用 Microsoft Hardware Program／正式程式碼簽章流程。
- 請先檢閱腳本，並只在你信任且確認為目標 Pd290／PL2305 裝置的電腦上安裝。

## 完整還原

以系統管理員 PowerShell 執行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Pd290Relay\Restore-All.ps1 -ConfirmRestoreAll
```

此操作會移除轉送服務與安裝程式建立的佇列、還原 Microsoft `usbprint.inf` 綁定，並移除 Pd290 測試憑證。

## 專案結構

- `Printer-Driver/`：Pd290 Unidrv 印表機套件
- `WinUSB-Relay/`：PL2305 WinUSB 綁定及還原腳本
- `Pd290Relay/`：Windows 服務原始碼、執行檔與管理腳本
- `Install-Pd290-New-Win11.ps1`：新 Windows 11 主機一鍵部署流程

## 注意事項

此專案目前未附開源授權。未取得授權前，著作權仍由原權利人保留。